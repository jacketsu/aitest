"""

Copyright (c) 2019 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import logging
import sys
import os

from logging import FileHandler, INFO
from logging.handlers import QueueHandler
from multiprocessing import Queue
from pathlib import Path
from threading import Thread

# Constants
LOG_PATH = 'logs'
LOG_FILENAME = 'AiSvcTest'
# LOG_FILE = "{0}/{1}.log".format(LOG_PATH, LOG_FILENAME)
LOG_FILE = os.path.join(LOG_PATH, LOG_FILENAME+".log")
DATE_FORMAT = "%H:%M:%S"
MESSAGE_FORMAT = "%(asctime)s.%(msecs)03d  %(levelname)7s %(message)s"  # level name can be an empty string
FORMATTER = logging.Formatter(MESSAGE_FORMAT, datefmt=DATE_FORMAT)


INFO_PLUS = INFO + 1
CONSOLE = INFO_PLUS + 1
PID = os.getpid()
QUEUE = Queue(-1)


class AiSvcTestLogger:
    queue_handler = None

    def __init__(self, name):
        self.logger = logging.getLogger(name)

    def console(self, message):
        self.__check_process()
        self.logger.log(CONSOLE, message)

    def debug(self, message):
        self.__check_process()
        self.logger.debug(message)

    def error(self, message):
        self.__check_process()
        self.logger.error(message)

    def info(self, message):
        self.__check_process()
        self.logger.log(INFO_PLUS, message)

    def log(self, level, message):
        self.__check_process()
        self.logger.log(level, message)

    def warning(self, message):
        self.__check_process()
        self.logger.warning(message)

    def add_file(self, file: Path, no_console=False):
        if not file.parent.exists():
            file.parent.mkdir(parents=True)
        file_handler = FileHandler(str(file))
        file_handler.setFormatter(FORMATTER)
        self.logger.addHandler(file_handler)
        if no_console:
            self.logger.propagate = False

    def __check_process(self):
        if not self.queue_handler and os.getpid() != PID:
            self.queue_handler = QueueHandler(QUEUE)
            for handler in self.logger.handlers:
                self.logger.removeHandler(handler)
            self.logger.addHandler(self.queue_handler)


def __log_listener():
    while True:
        record = QUEUE.get()
        if record:
            logging.getLogger(record.name).handle(record)


def start_log_listener():
    Thread(target=__log_listener, daemon=True).start()


def initialize_logging():
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    logging.addLevelName(INFO_PLUS, '')  # Create a log level that has an empty string for a name
    logging.addLevelName(CONSOLE, '')  # Create a console log level that has an empty string for a name
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(INFO_PLUS)  # Change to CONSOLE to log only console log messages
    console_handler.setFormatter(FORMATTER)
    root_logger.addHandler(console_handler)
    start_log_listener()


def getConsoleHandler():
    """ Creates a new console handler for system out """
    consoleHandler = logging.StreamHandler(sys.stdout)
    consoleHandler.setLevel(logging.INFO)
    consoleHandler.setFormatter(FORMATTER)
    return consoleHandler

def getFileHandler():
    """ Creates a new log file handler """
    # fileHandler = RotatingFileHandler(LOG_FILE, maxBytes=2000000, backupCount=10)
    fileHandler = FileHandler(LOG_FILE)
    fileHandler.setLevel(logging.INFO)
    fileHandler.setFormatter(FORMATTER)
    return fileHandler


def initializeLogger():
    """  Initializes the root logger for this CLI application """
    # Create logs directory & all intermediate directories if don't exists
    if not os.path.exists(LOG_PATH):
        try:
            os.makedirs(LOG_PATH)
        except OSError:
            print("Creation of log directory %s failed" % LOG_PATH)

    # create logger
    rootLogger = logging.getLogger()
    rootLogger.setLevel(logging.INFO)  # better to have too much log than not enough
    rootLogger.addHandler(getConsoleHandler())
    rootLogger.addHandler(getFileHandler())
    return rootLogger
