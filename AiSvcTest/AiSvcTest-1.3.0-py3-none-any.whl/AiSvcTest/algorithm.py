"""

Copyright (c) 2019 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import time
from datetime import datetime
from pathlib import Path

import requests
import threading
import urllib

from requests.exceptions import ConnectionError

from AiSvcTest.logs import AiSvcTestLogger
from AiSvcTest.utils import writeFile, createFolder, getRetryConfiguration
from AiSvcTest.transaction_helper import getTransactionUrl, getSubscriptionKey, validateOutputDicoms, verifyTransactionStatus
from AiSvcTest.constants import *

logger = AiSvcTestLogger('AiSvcTest.transaction_manager')

class Algorithm:
    """
    A class for executing AiService algorithm.

    Attributes:
        API_OUTFILE (str): The output file for persisted the results from API execution.
    """
    API_OUTFILE = ''
    JSON_DATA = {}   # JSON data to be sent to api
    HEADERS = {'Content-type': 'application/json',
               OCP_APIM_SUBSCRIPTION_KEY: getSubscriptionKey()}
    GLOBAL_COUNTER = 0

    # Constructor
    def __init__(self, url, is_self_host):
        """
        Constructor

        Args:
            url (str): REST endpoint URL for the API.
        """
        self.api_endpoint = url
        self.transaction_id = None
        self.threadLock = threading.Lock()
        self.selfhost = is_self_host

    def with_results(self, transaction_id=None, studies=None, results_path=None, config_data=None):
        """
        Args:
            transaction_id(int): Unique transaction identifier for the API.
            studies (str):
            results_path (str): Output folder to store results.
            config_data: Configuration
        """
        if results_path:
            results_path = Path(results_path)
            self.transaction_id = transaction_id
            createFolder(str(results_path / str(transaction_id)))
            self.API_OUTFILE = str(results_path / str(transaction_id) / AI_SERVICE_RESPONSE_FILENAME)
            if config_data is None:
                self.JSON_DATA = {"transactionId": transaction_id,
                                  "transactionURL": getTransactionUrl(),
                                  "uris": studies}
            else:
                self.JSON_DATA = {"transactionId": transaction_id,
                                  "transactionURL": getTransactionUrl(),
                                  "uris": studies,
                                  "configuration": config_data}
            return self

    def execute(self, path, http_method):
        """
        Algorithm Execution calling it's REST Service Endpoint through HTTP GET.
        Retries 3 times (configured in constants.py) before giving up.

        Args:
            path (str): Path to be appending to the base url used when creating this instance
            http_method (str): HTTP GET or HTTP POST that needs to be used.

        Returns:
            Response from the Algorithm's REST HTTP Request.
        """
        global_counter = 0
        start_time = datetime.now()
        max_retries = getRetryConfiguration()
        execution_url = self.api_endpoint + path
        while True:
            with self.threadLock:
                global_counter += 1

            if global_counter > max_retries:
                logger.info(ALGO_CONNECTION_ISSUE % (http_method, execution_url))
                break

            try:
                logger.debug(EXECUTE_ALGO_HTTP_ENDPOINT % (http_method, execution_url, self.HEADERS, self.JSON_DATA))
                logger.info(LOG_SPACER)
                logger.info(OUTZ + http_method + " " + execution_url)
                logger.info(HSPACE + "Job sent to AI service")
                logger.info(LOG_SPACER)

                if http_method == 'GET':
                    response = requests.get(url=execution_url, json=self.JSON_DATA, headers=self.HEADERS)
                else:
                    response = requests.post(url=execution_url, json=self.JSON_DATA, headers=self.HEADERS)

                if not self.selfhost:
                    verified_status = verifyTransactionStatus(self.transaction_id)
                    # logic to see 200 code
                    if not verified_status:
                        logger.info('')
                        logger.error('"ERROR: POST to /aiservice/1/jobs returned before the job finished processing"')

                    # extracting response text
                    if response.ok:
                        logger.debug(ALGO_RESPONSE_MSG % (http_method, response.text))
                        elapsed_time = datetime.now() - start_time
                        writeFile(self.API_OUTFILE, response.text)
                        validateOutputDicoms(os.path.dirname(self.API_OUTFILE))
                        logger.info('Completed in     ' + str(elapsed_time))
                    else:
                        logger.debug(ERROR_ALGO_RESPONSE_MSG % (response.status_code, response.text))
                        response.raise_for_status()
            except ConnectionError as err:
                response = err.args[0]
                logger.debug(ALGO_HTTP_CONNECTION_ERROR % (http_method, response))

            if Algorithm.recoverable(response, execution_url, http_method, global_counter):
                continue
            return response

    @staticmethod
    def recoverable(error, url, http_method, counter=1):
        """
        This function will retry requests that do return temporary recoverable errors,
        introducing an incremental sleep delay (number of retry x 10 seconds).
        At this moment it supports: 501, 502, 503, 504

        Args:
            error (obj): Error object
            url (str): REST endpoint URL for the API
            http_method (str): HTTP Request method
            counter (int): Number of retry attempt tried.
        """
        if hasattr(error, 'status_code'):
            if error.status_code in [501, 502, 503, 504]:
                error = "HTTP STATUS CODE: %s" % error.status_code
            else:
                return False

        delay = 5 * counter  # incremental sleep delay
        logger.info(ALGO_RETRY % (http_method, url, counter, delay))
        logger.debug(ALGO_RETRY_REQUEST % (counter, error))
        time.sleep(delay)

        return True

    def shutdown_service(self):
        service_stop_url = self.api_endpoint + '/aiservice/1/shutdown'
        try:
            response = requests.post(url=service_stop_url, headers=self.HEADERS)
        except requests.RequestException:
            response = requests.Response()
            response.status_code = 200
        return response

    def check_live(self, quiet: bool = False, self_host: bool = False, timeout: float = TIMER_REFRESH) -> requests.Response:
        service_health_url = self.api_endpoint + '/aiservice/1/live'
        if not self_host:
            if not quiet:
                logger.info(LOG_SPACER)
            response = requests.get(url=service_health_url, headers=self.HEADERS, timeout=timeout)
            if not quiet:
                logger.info(OUTZ + "GET "+service_health_url)
        else:
            logger.info("Self hosted systems do not have an integrated liveness chesk")
            # do we get a response on an HTML connectio check instead?
            response = True
        return response
