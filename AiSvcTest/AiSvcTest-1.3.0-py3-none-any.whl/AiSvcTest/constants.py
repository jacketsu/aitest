"""

Copyright (c) 2019 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""

import os

############################
# Application Constants
############################
# Persistant File detals.
STUDIES_FOLDER = os.path.join(os.path.dirname(__file__), "work", "transaction_manager", "data", "studies")
RESULTS_FOLDER = os.path.join(os.path.dirname(__file__), "work", "transaction_manager", "data", "results")

# Transaction Manager Endpoints
TRANSACTION_ENDPOINT = "/transaction"
TRANSACTION_HEALTH_ENDPOINT = "/health"
TRANSACTION_SHUTDOWN_ENDPOINT = "/shutdown"
TRANSACTION_CREATE_ENDPOINT = "/transaction/1/transactions"
OCP_APIM_SUBSCRIPTION_KEY = 'ocp-apim-subscription-key'

# Algorithm REST Endpoint Request
ALGO_EXECUTE_HTTP_METHOD = 'POST'   # Currently supports only 'GET' / 'POST'
AI_SERVICE_RESPONSE_FILENAME = 'ai_service_response.txt'

TIMER_REFRESH = 15.0      # default is 15.0, 300 for debugging

# Transaction Manager Constants
PRIORITY_ID = 1
SERVICE_ID = 1
ACCESION_NUMBER_PREFIX = "ACCXN000"
STUDY_UID_PREFIX = "STUDY-UID"
RESULT_TYPE = "FROM_AI_SERVICE"
LOG_SPACER = ""

# Transaction Results persisted.
DOCUMENT_PREFIX = "-documents"
DOCUMENT_SUFFIX = ".json"
RESULT_PREFIX = "-results"
RESULT_SUFFIX = ".json"
TRANSACTION_PREFIX = "transaction-"
TRANSACTION_SUFFIX = ".json"

# Global Constants
FLASK_ENV = "development"
PING_SLEEP_SECONDS = 2

############################
# Application Help Messages
############################
# Constants for Help messages
HELP_TOOL_DESCRIPTION = "Test the AI Service for AI Developer"
HELP_INPUT = "Input files path"
HELP_OUTPUT = "Output files path"
HELP_AISERVICE = "REST endpoint of the AI Service. Provide complete URL with http:// or https:// string"
HELP_KEEPALIVE = "This option is specified when the service will remain running after the current operation"
HELP_SELFHOST = "Run test agaist a server not hosted in the AIM Cloud"
HELP_HOST = "The External IP address of the machine running the AI Service Test"


############################
# Application Error Messages
############################
# Constants for Error messages
ERROR_INVALID_INPUT = "Specified input path '%s' does not exist."
ERROR_INVALID_AI_SERVICE_URL = "Specified Ai Service URL doesnot start with http:// or https://"
ERROR_SAME_INPUT_AND_OUTPUT = "Input path '%s' and ouptut path '%s' cannot be same."
ERROR_COULDNOT_CREATE_FOLDER = "Could not create directory '%s'"
ERROR_COULDNOT_WRITE_FILE = "An error occured trying to write to file '%s'. Either path is incorrect or permission denied!"
ERROR_COULDNOT_READ_FILE = "An error occured trying read file '%s'. Either path is incorrect or permission denied!"
ERROR_COULDNOT_PARSE_JSON = "An error occured in reading JSON file '%s'. Incorrect JSON format."
ERROR_NO_DICOM_IMAGES = "No dicom images found in input path '%s'"
ERROR_RECREATE_FOLDER = "Could not re-create directory '%s'"
ERROR_RETRIEVING_IP = "Unable to get IP Address of local system."
ERROR_EXECUTING_ALGO = "Error executing algorithm."
ERROR_NOT_RUNING_DEFAULT_FLASK_SERVER = "Not running with the default Python-Flask Server."
ERROR_CODE_400_BAD_REQUEST = "Bad Request"
ERROR_CODE_401_UNAUTHORIZED_ACCESS = "Unauthorized Access"
ERROR_CODE_415_UNSUPPORTED_MEDIA_TYPE = "Unsupported Media Type"
ERROR_CODE_500_CREATE_TRANSACTION = "Internal Server Error. Could not create transaction."
ERROR_CODE_500_CREATE_RESULT = "Internal Server Error. Could not create result."
ERROR_CODE_500_MULTIPART_FILE_UPLOAD = "Internal Server Error. Could not persist multipart file upload."
ERROR_TRANSACION_MANAGER_SHUTDOWN = "Could not shutdown Transaction Manager."
ERROR_TRANSACTION_MANAGER_CREATE_FAILED = "Could not create a new transaction from Transaction Manager."
ERROR_TRANSACTION_CREATE_FAILED = "Create Transaction failed. Error: %s %s"
ERROR_TRANSACTION_MANAGER_NOT_UP = "Transaction Manager is not running."
ERROR_TRANSACTION_MANAGER = "Transaction Manager liveness probe failed."
ERROR_ALGO_RESPONSE_MSG = "Algorithm execution failed with http status code %s. Response:\n%s"
ALGO_RETRY = "Algorithm HTTP %s Connection failed %s, retry attempt #%s in %s sec"

###############################
# Application Console Messages
###############################
# Constants for console messages
OUTZ   = "----> "
INZ    = "<---- "
HSPACE = "      "
AISVC_TEST_STARTED = "Executing AiSvcTest . . ."
ALGO_CONNECTION_ISSUE = "Could not connect via HTTP %s to Algorithm URL %s"
TRANSACTION_SHUTDOWN_MSG = "Transaction Manager shutting down..."
TRANSACTION_POST_REQUEST = "[TransactionManager] Create Transaction REQUEST: "
TRANSACTION_POST_RESPONSE = "[TransactionManager] Create Transaction RESPONSE: "
TRANSACTION_PUT_STATUS_REQUEST = "[TransactionManager] PUT Transaction Status REQUEST: "
TRANSACTION_PUT_STATUS_RESPONSE = "[TransactionManager] PUT Transaction Status RESPONSE: "
TRANSACTION_POST_RESULT_REQUEST = "[TransactionManager] Create Result REQUEST: "
TRANSACTION_POST_RESULT_RESPONSE = "[TransactionManager] Create Result RESPONSE: "
TRANSACTION_POST_DOCUMENT_REQUEST = INZ + "Receiving documents from AI Service: '%s'  ContentType: %s"
TRANSACTION_POST_RESULT_REQUEST = INZ + "Receiving AI Service Result: '%s'  ContentType: %s"
TRANSACTION_POST_DOCUMENT_RESPONSE = "[TransactionManager] POST Documents RESPONSE: "
TRANSFER_STUDY_FILE = OUTZ + "Copying Study File to AI Service: '%s'"
ALGO_EXECUTION_STARTED = "Executing Algorithm . . ."
ALGO_EXECUTION_SUCCESS = "Algorithm executed successfully."
ALGO_EXECUTION_FAILED = "Algorithm executed failed."
TRANSACTION_MANAGER_NOT_UP_RETRY = "Transaction Manager is not running, retry attempt #%s in %s seconds."
TRANSACTION_MANAGER_NOT_DOWN = "Could not shutdown Transaction Manager. Will retry in " + str(PING_SLEEP_SECONDS) + " seconds."
# TRANSACTION_ID_CREATED = "Created Transaction ID: %s"
TRANSACTION_ID_CREATED = "Created new Transaction: %s"

################################
# Valid configuration types
################################
# Constants for configuration types
CONFIG_SERVICE = "service"
CONFIG_SUBSCRIBER = "subscriber"
CONFIG_SUBSCRIPTION = "subscription"
CONFIG_ALL = [CONFIG_SERVICE, CONFIG_SUBSCRIBER, CONFIG_SUBSCRIPTION]
CONFIG_FILENAME = "jobconfig.json"

################################
# Application debug log Messages
################################
# Constants for log messages
START_AISVC_TEST = "*****\n"
VALIDATE_INPUT_ARGS = "Validating input arguments"
ARGS_INPUT = "input_folder = %s"
ARGS_OUTPUT = "output_folder = %s"
ARGS_CONFIG = "config_file = %s"
ARGS_AISVC = "ai_service = %s"
INPUT_FILES_FOUND = "Input files from %s %s"
TOTAL_FILES_FOUND = "%s files found from input folder \"%s\""
TOTAL_DICOM_FILES_FOUND = "%s dicom files found."
INPUT_DICOM_IMAGES = "DICOM Images: %s"
NEXT_ID = "Next ID: %s"
NEXT_INCREMENTED_ID = "Fetching getNextIncrementedId for folder: %s"
CHECK_TRANSACTION_ID = "Checking transactionId for folder: %s"
NEXT_ID_LESS_THAN_ONE = "Next ID %s is less than 1. Will return Next ID as 1."
PREVIOUS_TRANSACTION_CONTENTS = "Previous TransactionID %s Contents: %s"
SYSTEM_IP_ADDRESS = "IP Address: %s"
EXECUTE_ALGO_HTTP_ENDPOINT = "%s: %s  HEADER: %s JSON: %s"
ALGO_RETRY_REQUEST = "[Retry Attempt %s] Error Message: %s"
ALGO_HTTP_CONNECTION_ERROR = "No HTTP %s connection could be made. Error Message: %s"
ALGO_RESPONSE_MSG = "Algorithm HTTP %s Response: %s"
TRANSACION_SHUTDOWN_URL = "Transaction Manager Shutdown Endpoint:\n%s"
TRANSACTION_CONNECTION_REFUSED = "HTTP Connection refused. Retrying shutdown . . ."
TRANSACTION_SUBSCRIPTION_KEY_MISMATCH = "Subscription Key '%s' does not match AI Partner Key '%s'"
TRANSACTION_CONTENT_TYPE_MISMATCH = "Content-Type '%s' does not match required Content-Type '%s'"
MSG_REMOVING_FOLDER = "Removing existing directory: %s"
MSG_CREATING_FOLDER = "Creating folder: %s"
PERSISTED_FILE_UPLOAD = "%s multipart file upload persisted sucessfully to ouput location %s"
CACHING_TRANSACTION_RESPONSE = "TRANSACTION JSON Response persisted to file %s"
CACHING_RESULT_RESPONSE = "RESULT JSON Response persisted to file %s"
CACHING_DOCUMENT_RESPONSE = "DOCUMENT JSON Response persisted to file %s"
TRANSACTION_STATUS = "Transaction %s Status: %s"
CONTENT_TYPE_JSON = "application/json"
CONTENT_TYPE_FORM = "multipart/form-data"
MIME_TYPE_JSON = "application/json"
MIME_TYPE_DICOM = "application/dicom"
MIME_TYPE_DICOM_SC = "application/sc+dicom"
MIME_TYPE_DICOM_SR = "application/sr+dicom"
MIME_TYPE_DICOM_GSPS = "application/gsps+dicom"
MIME_TYPE_LOG = "text/log"
MIME_TYPE_DICOM_ALL = [MIME_TYPE_DICOM, MIME_TYPE_DICOM_SC, MIME_TYPE_DICOM_SR, MIME_TYPE_DICOM_GSPS]
MIME_TYPE_ALL = [MIME_TYPE_DICOM, MIME_TYPE_DICOM_SC, MIME_TYPE_DICOM_SR, MIME_TYPE_DICOM_GSPS, MIME_TYPE_JSON, MIME_TYPE_LOG]

################################
# Service Validations
################################
ERROR_VAL_FHIR = "Exactly one FHIR document allowed per transaction.  Sent %i "
ERROR_VAL_STATUS = "Transaction status may be set only once.  Statuses sent: %i "
ERROR_VAL_RESULT = "Exactly one Result is required per transaction.  Results updated %i times"
ERROR_VAL_DONE = "No calls are permitted after end of Transaction"

val_counters = {
    "fhir": 0,
    "dicom": 0,
    "result": 0,
    "status": 0,
    "complete": 0
}
