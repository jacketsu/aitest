"""

Copyright (c) 2019 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import os
import json
import time
import requests
import subprocess
import socket
import shutil
import sys
import inspect
import pydicom

# from AiSvcTest.logs import logger.info, logger.debug, logger.error, AiSvcTestLogger
from AiSvcTest.logs import AiSvcTestLogger
from AiSvcTest.constants import *
# from AiSvcTest.utils import getRetryConfiguration, getIpAddress, gracefullyExit,getNextIncrementedId
# from AiSvcTest.utils import *
from AiSvcTest import utils

TRANSACTION_MANAGER_PORT = os.getenv('AST_PORT', '8088')
SUBSCRIPTION_KEY = os.getenv('AST_KEY', 'AiSvcTestKey')
logger = AiSvcTestLogger('AiSvcTest.transaction_manager')
CONTENT_TYPE = 'Content-Type'
MIME_TYPE = 'mimetype'
override_host = None
global series_UIDs
series_UIDs = set()

def override_host_ip(new_address):
    if new_address:
        global override_host
        override_host = new_address
        logger.info(HSPACE)
        hostname, port = new_address.split(':')
        hostname = socket.gethostbyname(hostname)
        utils.set_host_address(hostname)
        logger.info("Setting Host address to: "+hostname)
        if port:
            logger.info("Setting Host port to: "+port)
            setTransactionManagerPort(port)
        logger.info(HSPACE)

def getTransactionManagerPort():
    return TRANSACTION_MANAGER_PORT

def setTransactionManagerPort(new_port):
    global TRANSACTION_MANAGER_PORT
    TRANSACTION_MANAGER_PORT = new_port

def getSubscriptionKey():
    return SUBSCRIPTION_KEY

def getTransactionUrl():
    """
    Returns Transaction Manager Simulator URL
    """
    # allow for override of URL from -H option
    user_specified_host = utils.get_external_address()
    if user_specified_host:
        return "http://" + user_specified_host + TRANSACTION_ENDPOINT
    else:
        return "http://" + utils.getIpAddress() + ":" + str(TRANSACTION_MANAGER_PORT) + TRANSACTION_ENDPOINT


def getCreateTransactionUrl():
    """
    Returns Transaction Manager URL to create a new transaction
    """
    return "http://" + utils.getIpAddress() + ":" + str(TRANSACTION_MANAGER_PORT) + TRANSACTION_CREATE_ENDPOINT


def getTransactionHealthUrl():
    """
    Returns Transaction Manager Simulator Health Check or Ping URL
    """
    return "http://" + utils.getIpAddress() + ":" + str(TRANSACTION_MANAGER_PORT) + TRANSACTION_HEALTH_ENDPOINT


def getTransactionShutdownUrl():
    """
    Returns Transaction Manager Simulator Shutdown URL
    """
    return "http://" + utils.getIpAddress() + ":" + str(TRANSACTION_MANAGER_PORT) + TRANSACTION_SHUTDOWN_ENDPOINT


def authorizeRequest(request):
    """
    This is an authorize interceptor to check if valid subscription key is provided.
    """
    caller = inspect.stack()[1][3]
    logger.debug("authorizeRequest() called from " + caller)

    token = request.headers.get(OCP_APIM_SUBSCRIPTION_KEY)
    if (token and token == SUBSCRIPTION_KEY):
        return True
    logger.error(TRANSACTION_SUBSCRIPTION_KEY_MISMATCH % (token, SUBSCRIPTION_KEY))
    print("ERROR - keys do not match: ", token, SUBSCRIPTION_KEY)
    return False

def verifyContentType(request, type):
    # headers, parameters, file_types
    # content-type, accept-type, the api key,
    token = request.headers.get(CONTENT_TYPE).split(';')[0]
    if (token and token == type):
        return True
    logger.debug(TRANSACTION_CONTENT_TYPE_MISMATCH % (token, type))
    return False

"""
    valid values:
        application/dicom
        application/sc+dicom
        application/sr+dicom
        application/gsps+dicom
        application/json
        test/log
"""
def verifyMimeType(fname, mimetype):
    mime_dict = {
        ".log": MIME_TYPE_LOG,
        ".json": MIME_TYPE_JSON,
        ".dcm": MIME_TYPE_DICOM_ALL
    }
    if mimetype is None:
        mimetype = "'None'"
    extn = os.path.splitext(fname)[1]
    mtype = mime_dict.get(extn)
    if mtype is None:
        logger.error("Unexpected file extension: must be .log, .dcm, or .json")
    elif extn == ".log" and mimetype != MIME_TYPE_LOG:
        logger.error(".log files require  a mimetype of '" + MIME_TYPE_LOG + "', found " + mimetype)
    elif extn == ".json" and mimetype != MIME_TYPE_JSON:
        logger.error(".json files require a mimetype of '" + MIME_TYPE_JSON + "', found " + mimetype)
    elif extn == ".dcm" and mimetype not in (MIME_TYPE_DICOM_ALL):
        logger.error(".dcm files require a mimetype of '" + "', '".join(MIME_TYPE_DICOM_ALL[:-1]) +
                 "' or '" + MIME_TYPE_DICOM_ALL[-1] + "', found " + mimetype)
# Will log error but allow processing to continue


def shutdownTransactionManager(retries):
    """
    Executes the required cleanups and shutdown tasks when the tool exit.
    """
    if (retries < 1):
        sys.exit()

    shutdown_endpoint = getTransactionShutdownUrl()
    try:
        retries -= 1
        requests.post(url=shutdown_endpoint, verify=False)
    except requests.exceptions.ConnectionError:
        logger.debug(TRANSACTION_MANAGER_NOT_DOWN)
        time.sleep(PING_SLEEP_SECONDS)  # 2 seconds sleep.
        shutdownTransactionManager(retries)
    except:
        logger.debug(TRANSACION_SHUTDOWN_URL % shutdown_endpoint)
        logger.error(ERROR_TRANSACION_MANAGER_SHUTDOWN)


def waitUntilTransactionManagerIsUp():
    """
    Verifies and waits until transaction manager is up and running.
    Retries a couple of times until giving up.
    """
    checkTransactionManager(utils.getRetryConfiguration())


def checkTransactionManager(retries):
    """
    Checks if the Transaction Manager Simulator is up and running.
    """
    if (retries < 1):
        logger.error(ERROR_TRANSACTION_MANAGER_NOT_UP)
        sys.exit()

    health_endpoint = getTransactionHealthUrl()
    try:
        retries -= 1
        requests.get(url=health_endpoint, verify=False)
    except requests.exceptions.ConnectionError:
        retryAttempt = utils.getRetryConfiguration() - retries
        logger.debug(TRANSACTION_MANAGER_NOT_UP_RETRY % (str(retryAttempt), retryAttempt * PING_SLEEP_SECONDS))
        time.sleep(retryAttempt * PING_SLEEP_SECONDS)
        checkTransactionManager(retries)
    except:
        logger.error(ERROR_TRANSACTION_MANAGER)
        utils.gracefullyExit()


def createNewTransaction():
    """
    Create's a new transaction using Transaction Manager and returns the transaction id.

    Returns:
        Transaction id of the newly created transaction.
    """
    transaction_endpoint = getCreateTransactionUrl()
    try:
        response = requests.post(url=transaction_endpoint, headers={OCP_APIM_SUBSCRIPTION_KEY: SUBSCRIPTION_KEY})
        if (response.status_code == 200):
            json_data = json.loads(response.text)
            transactionId = json_data["id"]
            logger.info(TRANSACTION_ID_CREATED % transactionId)
            return transactionId
        else:
            logger.error(ERROR_TRANSACTION_CREATE_FAILED % (response.status_code, response.text))
    except requests.exceptions.ConnectionError:
        logger.error(ERROR_TRANSACTION_MANAGER_CREATE_FAILED)
    except:
        logger.error(ERROR_TRANSACTION_MANAGER_CREATE_FAILED)
    return -1

def createTransactionId(output_folder):
    """
    Creates an unique transaction Id in an incremental way by scanning through
    the output folder where previous ids are stored as folder names.
    Simulates transaction abort condition by re-issuing the previous transactionId.

    Args:
        output_folder (str): Path where previous ids are stored as folder names.

    Returns:
        Next avaiable id, incremented value.
    """
    directories = list(filter(lambda d: os.path.isdir(os.path.join(output_folder, d)), os.listdir(output_folder)))
    directories = sorted(directories, key=lambda f: int(os.path.splitext(f)[0]))
    logger.debug(CHECK_TRANSACTION_ID % os.path.abspath(output_folder))
    if len(directories) == 0:
        logger.debug(NEXT_ID % '1')
        return 1
    else:
        nextID = int(directories[-1]) + 1
        if nextID < 1:
            logger.debug(NEXT_ID_LESS_THAN_ONE % nextID)
            logger.debug(NEXT_ID % '1')
            return 1

        previous_transaction_path = os.path.abspath(output_folder + '/' + directories[-1])
        dirContents = os.listdir(previous_transaction_path)
        logger.debug(PREVIOUS_TRANSACTION_CONTENTS % (directories[-1], ', '.join(dirContents)))
        if [f for f in dirContents if not f.startswith('.')] == []:
            # Previous transaction aborted without any records. Empty folder.
            logger.debug(NEXT_ID % str(directories[-1]))
            return directories[-1]
        else:
            # Checks if folder not empty
            if len(dirContents) > 1:
                pass
            else:
                # Empty folder, has empty or only one file i.e. transaction json file.
                logger.debug(NEXT_ID % str(directories[-1]))
                return directories[-1]
        logger.debug(NEXT_ID % str(nextID))
        return nextID

def verifyTransactionStatus(transactionId):
    work_transaction_path = RESULTS_FOLDER
    work_transaction_folder = os.path.join(work_transaction_path, str(transactionId))
    destination = os.path.abspath(os.path.join(work_transaction_folder,
            TRANSACTION_PREFIX + str(transactionId) + TRANSACTION_SUFFIX))
    with open(destination) as file:
        transaction_json = json.load(file)
    verified_status = False
    for s in transaction_json:
        if s['status'] == 'ANALYSIS_COMPLETE':
            verified_status = True
    return verified_status

def cachePostTransactionResponse(response_json_data, app_root, transactionId):
    if not response_json_data:
        return
    # Initialize the directory to persist the result json.
    work_transaction_path = RESULTS_FOLDER
    work_transaction_folder = os.path.join(work_transaction_path, str(transactionId))
    utils.createFolder(work_transaction_folder)
    destination = os.path.abspath(os.path.join(work_transaction_folder,
                                               TRANSACTION_PREFIX + str(transactionId) + TRANSACTION_SUFFIX))
    logger.debug(CACHING_TRANSACTION_RESPONSE % destination)
    utils.writeJsonFile(destination, response_json_data)


def cachePostResultResponse(response_json_data, app_root, transactionId):
    if not response_json_data:
        return
    # Initialize the directory to persist the result json.
    work_transaction_path = RESULTS_FOLDER
    work_transaction_folder = os.path.join(work_transaction_path, str(transactionId))
    utils.createFolder(work_transaction_folder)
    destination = os.path.abspath(os.path.join(work_transaction_folder,
                                               TRANSACTION_PREFIX + str(transactionId) +
                                               RESULT_PREFIX + RESULT_SUFFIX))
    logger.debug(CACHING_RESULT_RESPONSE % destination)
    utils.writeJsonFile(destination, response_json_data)

def cachePostDocumentResponse(response_json_data, app_root, transactionId, resultId):
    if not response_json_data:
        return
    # Initialize the directory to persist the document json.
    work_transaction_path = RESULTS_FOLDER
    work_transaction_folder = os.path.join(work_transaction_path, str(transactionId))
    utils.createFolder(work_transaction_folder)
    destination = os.path.abspath(os.path.join(work_transaction_folder,
                                               TRANSACTION_PREFIX + str(transactionId) +
                                               RESULT_PREFIX + '-' + str(resultId) +
                                               DOCUMENT_PREFIX + DOCUMENT_SUFFIX))
    logger.debug(CACHING_DOCUMENT_RESPONSE % destination)
    utils.writeJsonFile(destination, response_json_data)

def clean_work_folder(transactionId):
    studies_folder = os.path.join(STUDIES_FOLDER, str(transactionId))
    try:
        shutil.rmtree(studies_folder)
    except:
        logger.debug('Error removing  work directory: '+studies_folder)

def validateOutputDicoms(output_path):
    outputfiles = [f for f in os.listdir(output_path) if f.endswith('.dcm') | f.endswith('.DCM')]
    if len(outputfiles) != 0:
        for file in outputfiles:
            if file.endswith('dcm') | file.endswith('DCM'):
                dicom_file = os.path.join(output_path, file)
                try:
                    dcm = pydicom.dcmread(dicom_file)
                    series_UID = str(dcm.SeriesInstanceUID)
                    if series_UID in series_UIDs:
                        logger.error('Series UID {} for Dicom file {} is not unique'.format(series_UID, dicom_file))
                except Exception as e:
                    logger.error('Failed to parse dicom file {}. Exception: {}'.format(dicom_file, str(e)))
            else:
                pass
    else:
        pass

def storeDicomImages(input_folder, transactionId):
    """
    Get dicom files from the given input directory path and make it accessible
    to AiSvc Container for a given transactionId.

    Args:
        input_folder (str): The input path for dicom image files.
        transactionId (int): Current Transaction identifier.

    Returns:
        Comma separated list of hosted dicom files.
    """
    # Validate if we have dicom images provided by user.
    inputFiles = [f for f in os.listdir(input_folder) if f.endswith('.dcm') | f.endswith('.DCM')]
    if len(inputFiles) == 0:
        logger.error(ERROR_NO_DICOM_IMAGES % os.path.abspath(input_folder))
        utils.gracefullyExit()

    # Validate dicom files.
    dicom_files = []
    filenames = []
    for folder, subs, files in os.walk(input_folder):
        for filename in files:
            if filename.endswith('.dcm') | filename.endswith('.DCM'):
                file_path = os.path.abspath(os.path.join(folder, filename))
                try:
                    dcm = pydicom.dcmread(file_path)
                    series_UID = str(dcm.SeriesInstanceUID)
                    if series_UID != "":
                        series_UIDs.add(series_UID)
                    else:
                        logger.error('Dicom file {} series UID is empty'.format(file_path))
                    dicom_files.append(os.path.abspath(os.path.join(folder, filename)))
                    filenames.append(filename)
                except Exception as e:
                    logger.error('Dicom file: '+filename+' cannot be parsed. Reason: ' + str(e))

    logger.debug(TOTAL_DICOM_FILES_FOUND % len(dicom_files))
    for dicom_file in dicom_files:
        logger.debug("\t\t%s" % dicom_file)

    # Initialize dicom url for returning the URL String.
    dicom_url = 'http://' + utils.getIpAddress() + ':' + str(TRANSACTION_MANAGER_PORT) + '/study/' + str(transactionId) + '/'
    studies_folder = os.path.join(STUDIES_FOLDER, str(transactionId))
    utils.createFolder(studies_folder, True)

    # Copy dicom images.
    for dicom_file in dicom_files:
        try:
            shutil.copy2(dicom_file, studies_folder)
        except FileNotFoundError as e:
            logger.error(e)

    # Retrun an array of dicom image locations.
    location_array = [dicom_url + dicom_file for dicom_file in inputFiles]
    logger.debug(INPUT_DICOM_IMAGES % (','.join(location_array)))
    return location_array

def persistDocumentUploads(img_file, output_folder, transactionId):
    """
    Store the Transaction Document Upload Files from HTTP MultiPart Request to given output path.

    Args:
        img_file (object): The multipart file upload.
        output_folder (str): The output path for storing the results (FHIR JSON / Secondary Capture images.)
        transactionId (int): Current Transaction identifier.
    """
    if not img_file or img_file.filename == '':
        logger.debug('No filename in uploaded file')
        return False

    results_directory = os.path.join(output_folder, str(transactionId))
    utils.createFolder(results_directory)

    destination = os.path.abspath(os.path.join(results_directory, img_file.filename))
    img_file.save(destination)
    logger.debug(PERSISTED_FILE_UPLOAD % (img_file.filename, destination))
    return True


def createTransactionAndRetrieveId(app_root):
    try:
        work_transaction_path = RESULTS_FOLDER
        utils.createFolder(work_transaction_path)
        transactionId = createTransactionId(work_transaction_path)
        # work_transaction_folder = '{0}/{1}'.format(work_transaction_path, transactionId)
        work_transaction_folder = os.path.join(work_transaction_path, str(transactionId))
        utils.createFolder(work_transaction_folder)
    except Exception as e:
        logger.error("Creating "+work_transaction_folder+" Code: "+e.message)
        return -1
    return transactionId


def createResultAndRetrieveId(app_root, transactionId):
    work_transaction_path = RESULTS_FOLDER
    # work_transaction_folder = '{0}/{1}'.format(work_transaction_path, transactionId)
    work_transaction_folder = os.path.join(work_transaction_path, str(transactionId))
    try:
        logger.debug(MSG_CREATING_FOLDER % os.path.abspath(work_transaction_folder))
        utils.createFolder(work_transaction_folder)
    except Exception as e:
        logger.error("Creating tranaction folder "+work_transaction_folder+" Code: "+e.message)
        return -1

    try:
        resultId = utils.getNextIncrementedId(work_transaction_folder)
        work_result_folder = os.path.join(work_transaction_folder, str(resultId))
        utils.createFolder(work_result_folder)
    except Exception as e:
        logger.error("Creating result folder "+work_result_folder+" Code: "+e.message)
    return resultId

def createDocumentAndRetrieveId(img_file, app_root, transactionId, resultId):
    try:
        work_result_path = RESULTS_FOLDER
        work_result_folder = os.path.join(work_result_path, str(transactionId), str(resultId))
        logger.debug(MSG_CREATING_FOLDER % os.path.abspath(work_result_folder))
        utils.createFolder(work_result_folder)
        documentId = utils.getNextIncrementedId(work_result_folder)
        work_document_folder = os.path.join(work_result_folder, str(documentId))
        utils.createFolder(work_document_folder)
        destination = os.path.abspath(os.path.join(work_document_folder, img_file.filename))
        logger.debug(PERSISTED_FILE_UPLOAD % (img_file.filename, destination))
        img_file.save(destination)
    except Exception as e:
        logger.error("Exception creating "+destination+" Code: "+e.message)
        return -1
    return documentId
