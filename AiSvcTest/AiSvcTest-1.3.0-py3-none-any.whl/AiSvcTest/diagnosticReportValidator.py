import json
import sys
import re
import datetime

'''
Error Codes
'''
ERROR_MISSING_FIELD = 1
ERROR_INCORRECT_DATATYPE = 2
ERROR_INCORRECT_VALUE = 3
ERROR_MISSING_REFERENCE = 4
ERROR_EMPTY_STRING = 5
ERROR_LOADING_JSON = 6
ERROR_VALIDATION_EXCEPTION = 7
ERROR_CODE_NOT_FOUND = 8
ERROR_MULTIPLE_COMPONENT_VALUES = 9

class DiagnosticReportValidator:
    '''------------------------------------------------------------
    Validation:
      Call load_file( file_path) to load the json file
      Call validate() to validate the FHIR json
      Call get_errors() to retrive errors
      Call get_error_message(error) to generate an error message

    load_file and validate are separated to make it easy to write
    unit tests. After the file is loaded, it can be modifed with
    the get_report() method before validation is done.

    get_errors and get_error_message for two reasons. First, this
    allows unit tests to inspect error. Second, it allows prefix formatting
    to the error lines. For instance AiSvcTest will pre-pend each
    line with appropriate datetime and indenting.
    ------------------------------------------------------------'''

    def load_file(self, file_path: str):
        '''
        Load a json file to a python dict
        if fail, will not apply further checks
        '''

        self.__report = None
        self.__errors = []
        self.__references = dict()

        try:
            with open(file_path) as report:
                self.__report = json.load(report)
            return True
        except Exception as e:
            self.__add_error('.', data_key=None, data_value=None, error=ERROR_LOADING_JSON, should_be=e)
            return False

    def get_report(self):
        return self.__report

    def validate(self):
        '''
        go through the whole report,
        apply check logic to every component,
        return self.__result
        '''

        try:
            self.__build_reference_dict()
            self.__validate_report('.', self.__report)
        except BaseException as e:
            self.__add_error('.', data_key=None, data_value=None, error=ERROR_VALIDATION_EXCEPTION, should_be=str(e))

        return self.__errors

    '''------------------------------------------------------------
    Managing errors

    The collection __result will contain a list of error objects upon
    the completion of analysis. The list is separated from the console
    output such that we can build unit tests.
    ------------------------------------------------------------'''

    class Error:
        def __init__(self, object_path, data_key, data_value=None, error=None, should_be=None):
            self.object_path = object_path
            self.data_key = data_key
            self.data_value = data_value
            self.error = error
            self.should_be = should_be

    def get_errors(self):
        return self.__errors

    def __add_error(self, object_path, data_key=None, data_value=None, error=None, should_be=None):
        '''
        whenever there is an invalid value,
        update the self.result dict
        '''
        error = self.Error(object_path, data_key, data_value, error, should_be)
        self.__errors.append(error)

    def get_error_message(self, error):
        '''
        taking one error as parameter
        return a formatted error message
        '''
        no = "FHIR{:02d}: ".format(error.error)
        if error.error == ERROR_MISSING_FIELD:
            if error.object_path != '.':
                error_message = no+'Missing required field {}.{}'.format(error.object_path, error.data_key)
            else:
                error_message = no+'Missing required field {}{}'.format(error.object_path, error.data_key)
        elif error.error == ERROR_INCORRECT_DATATYPE:
            if len(error.should_be) <= 1:
                should_be = error.should_be[0]
            else:
                should_be = str(error.should_be[0])
                for s in error.should_be[1:]:
                    should_be += (' or '+str(s))
            if error.object_path == '.':
                error_message = no+'Wrong data type for field {}{}, expected {} but found {}'.format(error.object_path, error.data_key, should_be, type(error.data_value))
            else:
                error_message = no+'Wrong data type for field {}.{}, expected {} but found {}'.format(error.object_path, error.data_key, should_be, type(error.data_value))
        elif error.error == ERROR_INCORRECT_VALUE:
            if len(error.should_be) <= 1:
                should_be = error.should_be[0]
            else:
                should_be = ''
                for s in error.should_be:
                    should_be += (s + ' or ')
            if error.object_path == '.':
                error_message = no+'Wrong data value for field {}{}, expected {} but found {}'.format(error.object_path, error.data_key, error.should_be, error.data_value)
            else:
                error_message = no+'Wrong data value for field {}.{}, expected {} but found {}'.format(error.object_path, error.data_key, error.should_be, error.data_value)
        elif error.error == ERROR_MISSING_REFERENCE:
            error_message = no+'Referenced object {} not found. Was referenced at {}'.format(error.should_be, error.object_path)
        elif error.error == ERROR_EMPTY_STRING:
            if error.object_path == '.':
                error_message = no+'Found empty string for field {}{}'.format(error.object_path, error.data_key)
            else:
                error_message = no+'Found empty string for field {}.{}'.format(error.object_path, error.data_key)
        elif error.error == ERROR_LOADING_JSON:
            error_message = no+'Output FHIR cannot be loaded. reason: {}. Please make sure it follows standard JSON format.'.format(error.should_be)             # print(error_message)
        elif error.error == ERROR_VALIDATION_EXCEPTION:
            error_message = no+'FHIR Validation failed to continue due to reason: {}.'.format(error.should_be)
        elif error.error == ERROR_CODE_NOT_FOUND:
            error_message = no+'Missing required code at {}. At least one code must be found matching:{}.'.format(error.object_path, error.should_be)
        elif error.error == ERROR_MULTIPLE_COMPONENT_VALUES:
            error_message = no+'Multiple value* members were encountered at {}.'.format(error.object_path)
        else:
            error_message = no+'Unexpected error code in FHIR Validator'

        return error_message

    '''------------------------------------------------------------
    Managing References

    References are managed by first walking this list of contained objects
    to build a map of contained objects. Later references can be dereferenced.
    ------------------------------------------------------------'''

    class Reference:
        def __init__(self, object_path, json_object):
            self.object_path = object_path
            self.object = json_object

    def get_reference(self, reference: str):
        '''
        Provides quick access to contained objects for unit testing
        '''
        return self.__references[reference]

    def __build_reference_dict(self):
        '''
        Walks the list of contained objects and builds
        a dict for future object dereferencing.
        '''
        if self.__check_required_field('.', self.__report, 'contained', [list]):
            for c in self.__report['contained']:
                self.__references['#'+c['id']] = self.Reference('.contained['+str(self.__report['contained'].index(c))+']', c)

    def __dereference(self, path, obj, resourceType):
        '''
        If the specified object is a reference, lookup the referenced
        object and return the reference object and its path
        '''
        if 'reference' in obj:
            object_id = obj['reference']
            if object_id in self.__references:
                obj = self.__references[object_id].object
                obj_path = self.__references[object_id].object_path
                if 'resourceType' in obj and obj['resourceType'] == resourceType:
                    return obj_path, obj
                else:
                    self.__add_error(obj_path, 'resourceType', obj['resourceType'], ERROR_INCORRECT_VALUE, resourceType)
                    return obj_path, obj
            else:
                self.__add_error(path+'.reference', error=ERROR_MISSING_REFERENCE, should_be='')
                return None, None
        else:
            return path, obj

    '''------------------------------------------------------------
    Simple Validation Helpers

    The methods are used within a the methods that check FHIR objects.
    ------------------------------------------------------------'''

    def __check_required_field(self, object_path, json_object, data_field, data_type, data_match=False, correct_data=[]):
        '''
        check for data existance and type. If anything invalid, update self.__result dict
        parameters:
        json_object: the component object of diagnosticReport json. Such as device and study
        data_field: the data field name that being checked inside the json_object
        data_type: the correct data type
        return:
        None
        '''

        # Verify field exists
        if data_field not in json_object:
            self.__add_error(object_path, data_field, error=ERROR_MISSING_FIELD, should_be='exist')
            return False

        # Verify data type
        if type(json_object[data_field]) not in data_type:
            self.__add_error(object_path, data_field, data_value=json_object[data_field], error=ERROR_INCORRECT_DATATYPE, should_be=data_type)
            return False

        # String: Special Validations
        if type(json_object[data_field]) == str:

            # Required values
            if data_match and json_object[data_field] != correct_data and json_object[data_field] not in correct_data:
                self.__add_error(object_path, data_field, data_value=json_object[data_field], error=ERROR_INCORRECT_VALUE, should_be=correct_data)
                return False

            # Check for empty string
            if not json_object[data_field].strip() and data_field != 'valueString':
                self.__add_error(object_path, data_field, data_value=json_object[data_field], error=ERROR_EMPTY_STRING, should_be='Not Empty')
                return False

        return True

    def __check_optional_field(self, path, obj, data_field, data_type, data_match=False, correct_data=None):
        if data_field in obj:
            return self.__check_required_field(path, obj, data_field, data_type, data_match, correct_data)
        else:
            return False

    def __check_datetime_format(self, path, obj, data_field):
        if not re.match("^\\d\\d\\d\\d-\\d\\d-\\d\\dT\\d\\d:\\d\\d:\\d\\d(.\\d\\d?\\d?\\d?\\d?\\d?)?(Z|\\+\\d\\d:\\d\\d)$", data_field) is None:
            self.__add_error(path, data_key=data_field, data_value=obj[data_field], error=ERROR_INCORRECT_VALUE, should_be='iso format. Ex: 2012-12-09T15:33:28.830000+00:00 or 2012-12-09T15:33:28.830000Z')
            return False

        # try:
        #     # datetime = datetime.datetime.strptime(obj[data_field], '')
        #     date_time = obj[data_field].split("-")
        #     if len(date_time) == 3 and ('-' in date_time[2] or '+' in date_time[2]):
        #         return True
        #     else:
        #         self.__add_error(path, data_key=data_field, data_value=obj[data_field], error=ERROR_INCORRECT_VALUE, should_be='iso fomrat. Ex: 2012-12-09T15:33:28.830000+00:00')
        #         return False
        # except:
        #     self.__add_error(path, data_key=data_field, data_value=obj[data_field], error=ERROR_INCORRECT_VALUE, should_be='iso fomrat. Ex: 2012-12-09T15:33:28.830000+00:00')
        #     return False

    '''------------------------------------------------------------
    Structural Validations

    The below method walk the the FHIR.json file hierarchically.
    Each method checks one object.

    This section should be maintained top to bottom of the hierarchy.
    ------------------------------------------------------------'''

    def __validate_report(self, path, obj):
        '''
        Validates the DiagnosticReport object
        '''
        # check mandatory fields in diagnosticReport
        self.__check_required_field(path, obj, 'id', [str])
        self.__check_required_field(path, obj, 'resourceType', [str], True, 'DiagnosticReport')
        self.__check_optional_field(path, obj, 'conclusion', [str])
        self.__check_optional_field(path, obj, 'status', [str])
        self.__check_required_field(path, obj, 'contained', [list])

        if self.__check_required_field(path, obj, 'category', [dict]):
            self.__validate_coding_list(path+'category', obj['category'], 'RAD', 'Radiology', 'http://terminology.hl7.org/CodeSystem/v2-0074')

        if self.__check_required_field(path, obj, 'code', [dict]):
            self.__validate_coding_list(path+'code', obj['code'], code='68604-8', display=None, system='http://loinc.org')

        # retrieve device reference and apply checks to device
        if self.__check_required_field(path, obj, 'subject', [dict], False):
            device_path, device = self.__dereference(path+'subject', obj['subject'], 'Device')
            if device is not None:  # and device_path is not None:
                self.__validate_device(device_path, device)

        # retrieve study reference and apply checks to study
        if self.__check_required_field(path, obj, 'imagingStudy', [list]):
            for i in obj['imagingStudy']:
                # pass study_path_i into dereference
                study_path, study = self.__dereference(path+'imagingStudy', i, 'ImagingStudy')
                if study is not None:
                    self.__validate_study(study_path, study)

        # retrieve result references and apply checks to observations
        if self.__check_optional_field(path, obj, 'result', [list]):
            for r in obj['result']:
                obs_path, obs = self.__dereference(path+'result', r, 'Observation')
                if obs is not None:
                    self.__validate_observation(obs_path, obs, True)

        if self.__check_optional_field(path, self.__report, 'effectiveDateTime', [str]):
            self.__check_datetime_format(path, self.__report, 'effectiveDateTime')

    def __validate_coding_list(self, path, obj, code=None, display=None, system=None):
        # Look fr "coding" member
        if self.__check_required_field(path, obj, 'coding', [list]):
            path = path+".coding"
            found_required = False
            i = -1
            for c in obj['coding']:
                i = i + 1

                # Check required member
                if not self.__check_required_field(path+'['+str(i)+']', c, "code", [str]):
                    continue
                self.__check_optional_field(path+'['+str(i)+']', c, "display", [str])
                if not self.__check_required_field(path+'['+str(i)+']', c, "system", [str]):
                    continue

                # Look for required entry
                if (code is None or code == c["code"]) and (display is None or ('display' in c and display == c["display"])) and (system is None or system == c["system"]):
                    found_required = True

            if (code is not None or display is not None or system is not None) and found_required is False:
                text = ''
                if code is not None:
                    text += ' code=\'{}\''.format(code)
                if display is not None:
                    text += ' display=\'{}\''.format(display)
                if system is not None:
                    text += ' system=\'{}\''.format(system)
                self.__add_error(path, 'coding', None, ERROR_CODE_NOT_FOUND, text)

    def __validate_device(self, object_path, device):
        self.__check_required_field(object_path, device, 'manufacturer', [str])
        if self.__check_required_field(object_path, device, 'deviceName', [list]):
            for device_name in device['deviceName']:
                self.__check_required_field(object_path+'.deviceName['+str(device['deviceName'].index(device_name))+']', device_name, 'name', [str])
                self.__check_required_field(object_path+'.deviceName['+str(device['deviceName'].index(device_name))+']', device_name, 'type', [str], True, 'model-name')
        if self.__check_required_field(object_path, device, 'version', [list]):
            for version in device['version']:
                self.__check_required_field(object_path+'.version['+str(device['version'].index(version))+']', version, 'value', [str], False)

    def __validate_study(self, path, study):
        self.__check_required_field(path, study, 'status', [str], True, 'available')

        if self.__check_required_field(path, study, 'identifier', [list]):
            self.__validate_identifier(path+'.identifier', study['identifier'], 'ACSN', None, 'http://terminology.hl7.org/CodeSystem/v2-0203', '110180', 'Study Instance UID', 'http://dicom.nema.org/resources/ontology/DCM')

        if self.__check_required_field(path, study, 'subject', [dict]):
            patient_path, patient = self.__dereference(path, study['subject'], 'Patient')
            if patient is not None:
                self.__validate_patient(patient_path, patient)

        if self.__check_optional_field(path, study, 'procedureCode', [list]):
            for i in range(len(study['procedureCode'])):
                self.__validate_coding_list(path+'.procedureCode['+str(i)+']', study['procedureCode'][i], system='http://loinc.org')

        if self.__check_optional_field(path, study, 'started', [str]):
            self.__check_datetime_format(path, study, 'started')

    def __validate_result(self):
        result_list = [r['reference'] for r in self.__report['result']]
        for result in result_list:
            self.__validate_observation(self.__references[result]['object_path'], self.__references[result]['object'])

    def __validate_observation(self, path, observation, is_primary=True):
        self.__check_required_field(path, observation, 'status', [str], True, ['final', 'preliminary'])
        self.__check_optional_field(path, observation, 'derivedFrom', [list])

        if is_primary:
            if self.__check_required_field(path, observation, 'bodySite', [dict]):
                self.__validate_coding_list(path+'.bodySite', observation['bodySite'], system='http://www.radlex.org')

        if self.__check_required_field(path, observation, 'code', [dict]):
            if 'hasMember' in observation:
                self.__validate_coding_list(path+'.code', observation['code'], code='RID34785', system='http://www.radlex.org')
            else:
                self.__validate_coding_list(path+'.code', observation['code'], system="http://nuancepowerscribe.com/saf")

        if self.__check_optional_field(path, observation, 'component', [list]):
            self.__validate_component_list(path+'.component', observation['component'])

        # There is an option to have a single value directly on the observation
        # This is rarely (never) done for AI Marketplace

        self.__check_optional_field(path, observation, 'valueString', [str])
        self.__check_optional_field(path, observation, 'valueInteger', [int])
        self.__check_optional_field(path, observation, 'valueBoolean', [bool])

        if self.__check_optional_field(path, observation, 'valueQuantity', [dict]):
            self.__check_required_field(path+'.valueQuantity', observation['valueQuantity'], 'value', [float, int])
            self.__check_required_field(path+'.valueQuantity', observation['valueQuantity'], 'unit', [str])
            self.__check_optional_field(path+'.valueQuantity', observation['valueQuantity'], 'system', [str])

        if self.__check_optional_field(path, observation, 'valueCodeableConcept', [dict]):
            self.__validate_coding_list(path+'.valueCodeableConcept', observation['valueCodeableConcept'])

        # TODO: fix iteration
        if self.__check_optional_field(path, observation, 'hasMember', [list]):
            for m in observation['hasMember']:
                obs_path, obs = self.__dereference(path+'.hasMember[?]', m, 'Observation')
                if obs is not None:
                    self.__validate_observation(obs_path, obs, is_primary=False)

    def __validate_component_list(self, path, component_list: list):
        dicom_system = 'http://dicom.nema.org/resources/ontology/DCM'
        radlex_system = 'http://nuancepowerscribe.com/ai'
        for i in range(len(component_list)):
            display = component_list[i]['code']['coding'][0]['display'].replace(" ", "").lower()
            if display == 'seriesnumber':
                self.__validate_individual_component(path+'['+str(i)+']', component_list[i], 'valueInteger', '113607', 'Series Number', dicom_system)
            elif display == 'seriesuid':
                self.__validate_individual_component(path+'['+str(i)+']', component_list[i], 'valueString', '112002', 'Series UID', dicom_system)
            elif display == 'instancenumber':
                self.__validate_individual_component(path+'['+str(i)+']', component_list[i], 'valueInteger', '113609', 'Instance Number', dicom_system)
            elif display == 'sopclassuid':
                self.__validate_individual_component(path+'['+str(i)+']', component_list[i], 'valueString', '110181', 'SOP Class UID', dicom_system)
            elif display == 'sopinstanceuid':
                self.__validate_individual_component(path+'['+str(i)+']', component_list[i], 'valueString', '121126', 'SOP Instance UID', dicom_system)
            elif display == 'findingqualifier':
                self.__validate_individual_component(path+'['+str(i)+']', component_list[i], 'valueString', None, 'Finding Qualifier', radlex_system)
            else:
                self.__validate_individual_component(path+'['+str(i)+']', component_list[i])

    def __validate_individual_component(self, path, component, valueField=None, code=None, display=None, system=None):
        # If we know the type of value we should have, ensure we have it
        if valueField == 'valueString':
            self.__check_required_field(path, component, 'valueString', [str])
        elif valueField == 'valueInteger':
            self.__check_required_field(path, component, 'valueInteger', [int])
        elif valueField == 'valueBoolean':
            self.__check_required_field(path, component, 'valueBoolean', [bool])
        else:
            self.__check_optional_field(path, component, 'valueString', [str])
            self.__check_optional_field(path, component, 'valueInteger', [int])
            self.__check_optional_field(path, component, 'valueBoolean', [bool])

        # Make sure we have exactly one value
        count = 0
        if 'valueString' in component:
            count += 1
        if 'valueInteger' in component:
            count += 1
        if 'valueBoolean' in component:
            count += 1
        if 'valueCodeableConcept' in component:
            count += 1
        if 'valueQuantity' in component:
            count += 1
        if count != 1:
            self.__add_error(path, error=ERROR_MULTIPLE_COMPONENT_VALUES)

        if self.__check_required_field(path, component, 'code', [dict]):
            self.__validate_coding_list(path+'.code', component['code'], code, display, system)

        if self.__check_optional_field(path, component, 'valueQuantity', [dict]):
            self.__check_required_field(path+'.valueQuantity', component['valueQuantity'], 'value', [float, int])
            self.__check_required_field(path+'.valueQuantity', component['valueQuantity'], 'unit', [str])
            self.__check_optional_field(path+'.valueQuantity', component['valueQuantity'], 'system', [str])

        if self.__check_optional_field(path, component, 'valueCodeableConcept', [dict]):
            self.__validate_coding_list(path+'.valueCodeableConcept', component['valueCodeableConcept'])

    def __validate_patient(self, path, patient):
        if self.__check_required_field(path, patient, 'identifier', [list]):
            self.__validate_identifier(path+'.identifier', patient['identifier'], 'MR', None, 'http://terminology.hl7.org/CodeSystem/v2-0203')

    def __validate_identifier(self, object_path, identifier, required_code=None, required_display=None, required_system=None,
                              optional_code=None, optional_display=None, optional_system=None):

        new_path = object_path+'[0]'
        self.__check_required_field(new_path, identifier[0], 'use', [str], True, 'usual')
        self.__check_required_field(new_path, identifier[0], 'value', [str])

        if self.__check_required_field(new_path, identifier[0], 'type', [dict]):
            self.__validate_coding_list(new_path+'.type', identifier[0]['type'], required_code, required_display, required_system)

        if optional_code is not None and len(identifier) > 1:
            new_path = object_path + '[1]'
            self.__check_required_field(new_path, identifier[1], 'use', [str], True, 'official')
            self.__check_required_field(new_path, identifier[1], 'value', [str])

            if self.__check_required_field(new_path, identifier[1], 'type', [dict]):
                self.__validate_coding_list(new_path+'.type', identifier[1]['type'], optional_code, optional_display, optional_system)

'''------------------------------------------------------------
main()

This file can run stand-alone to validate files.
------------------------------------------------------------
'''

def main():
    print()
    if len(sys.argv) != 2:
        print("USAGE: python diagnosticReportValidator.py {filename}")
        print()
        print("Validates FHIR/JSON files for Nuance AI Marketplace.")
        print()
        return
    file_path = sys.argv[1]

    print("Validating {}".format(file_path))
    drv = DiagnosticReportValidator()
    if drv.load_file(file_path):
        drv.validate()
        results = drv.get_errors()
        if len(results) > 0:
            print("Errors detected:")
            for r in results:
                print(drv.get_error_message(r))
        else:
            print("No errors")
    else:
        print("Unable to load file.")
    print()

if __name__ == "__main__":
    main()
