"""

Copyright (c) 2019 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import logging
import requests
from datetime import datetime

from pathlib import Path

# __spec__ is set when the -m flag is passed to tell Python how to load a module, loading as a module implies that the module is on the path
# if __spec__.name is relative then python is trying to run the package without loading it as module and we need to help it along
if not __spec__ or __spec__.name == "__main__":
    # Import system modules
    from inspect import stack as inspect_stack
    import sys

    # Find the module folder
    __module_main = None

    # Find the script if run using execfile (this is not very common) or exec
    for entry in inspect_stack():
        if entry[1].startswith('<'):
            pass
        elif entry[1].upper().startswith(sys.exec_prefix.upper()):
            pass
        else:
            __module_main = Path(entry[1])

    # For frozen code: see https://docs.python-guide.org/shipping/freezing/
    if getattr(sys, 'frozen', False):
        __module_main = Path(sys.executable)

    # sys.argv[0] is always the script name: https://docs.python.org/3/library/sys.html#sys.argv
    if not __module_main:
        __module_main = Path(sys.argv[0])

    # Sometimes the runpy module is used
    if __module_main.name == "runpy.py":
        __module_main = Path(__file__)

    # Expand ~ and resolve and any links, aliases, shortcuts or junctions
    __module_main = __module_main.expanduser().resolve()

    # Remove things as they are found, we can't blindly jump to a specific parent
    if __module_main.name == "__main__.py":
        __module_main = __module_main.parent
    if __module_main.name == "AiSvcTest":
        __module_main = __module_main.parent

    # Prepend the folder containing the module folder to the path
    sys.path.insert(0, str(__module_main))

from AiSvcTest.arguments import parseArgs, validateInputs
from AiSvcTest.dispatcher import Dispatcher
from AiSvcTest.utils import showBanner, set_external_adderss
from AiSvcTest.transaction_manager import start_transaction_manager, TransactionManager
from AiSvcTest.transaction_helper import waitUntilTransactionManagerIsUp, createNewTransaction, getTransactionShutdownUrl
from AiSvcTest.logs import initialize_logging, AiSvcTestLogger
from AiSvcTest.constants import *


# Globals
keep_alive = False
self_host = False

initialize_logging()
logger = AiSvcTestLogger('AiSvcTest')


def set_log_target(output_dir):
    # addNewLogger(os.path.join(output_dir, "aisvctest.log"))
    logger.add_file(Path(output_dir, "aisvctest.log"))
    logger.info("Test log location: " + os.path.join(output_dir, "aisvctest.log"))


def main():
    """Entry point for the AiSvcTest."""
    logger.debug(START_AISVC_TEST)

    showBanner()

    logger.info(AISVC_TEST_STARTED+' '+datetime.now().strftime('%m/%d/%Y'))

    # Pre Steps - Arguments Validation
    args = parseArgs()
    isValid = validateInputs(args)

    # set the log target path
    set_log_target(args.output)

    # create flags and read from input
    global keep_alive
    keep_alive = args.keepalive
    global self_host
    self_host = args.selfhost

    if args.host is not None:
        set_external_adderss(args.host)

    # Create the CLI Banner
    # Run the Transaction Manager as a subprocess
    # startTransactionManagerSimulator(args.output)
    transaction_manager = start_transaction_manager(args.output)

    # Verify and wait until Transaction Manager is up and running.
    waitUntilTransactionManagerIsUp()

    # Simulate creating a Transaction.
    transaction_id = createNewTransaction()

    if transaction_id == -1:
        gracefully_exit(transaction_manager)
    # Invoke dispatcher for AI Service Testing.
    if isValid:
        dispatcher = Dispatcher(args.aiservice, args.selfhost)
        configFile = os.path.join(args.input, CONFIG_FILENAME)

        # Self-hosted mode does not support liveness check
        if not self_host:
            if dispatcher.check_live():
                logger.info(HSPACE + "Liveness check completed successfully")
                dispatcher(args.input, args.output, '/aiservice/1/jobs', transaction_id, configFile)
            else:
                print("[ERROR]  Service is not live")   # shown on console
        else:
            dispatcher(args.input, args.output, '/aiservice/1/jobs', transaction_id, configFile, transaction_manager)

        # self-host servers do not implement /shutdown service
        if not keep_alive or self_host:
            if dispatcher.kill_service():
                logger.info(HSPACE + "Service shutdown completed successfully")
            else:
                logger.error(HSPACE + "Service shutdown not complete")

    # Post Steps, shut down the transaction manager and exit.
    gracefully_exit(transaction_manager)
    logger.info(LOG_SPACER)
    logger.info("Please check the log file for detailed status  ------------------")
    logger.info(LOG_SPACER)


def gracefully_exit(transaction_manager: TransactionManager):
    """
    Gracefully Exit this application.
    """
    if transaction_manager is not None:
        requests.post(getTransactionShutdownUrl())
    logging.shutdown()  # prevent deadlock


if __name__ == '__main__':
    main()
