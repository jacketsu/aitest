"""

Copyright (c) 2019 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import sys
import json
import logging
from datetime import datetime
from enum import Enum
from pathlib import Path

from flask import Flask, request, send_from_directory
from flask_restful import Api, Resource
from flask_env import MetaFlaskEnv
from multiprocessing import Pipe
from multiprocessing.context import Process
from threading import Thread
from urllib.parse import urlparse

from AiSvcTest.constants import *
from AiSvcTest.diagnosticReportValidator import DiagnosticReportValidator
from AiSvcTest.logs import AiSvcTestLogger
from AiSvcTest.utils import isNotBlank
from AiSvcTest.transaction_helper import authorizeRequest, persistDocumentUploads
from AiSvcTest.transaction_helper import verifyContentType, verifyMimeType
from AiSvcTest.transaction_helper import cachePostTransactionResponse, cachePostResultResponse, cachePostDocumentResponse
from AiSvcTest.transaction_helper import createTransactionAndRetrieveId, createResultAndRetrieveId
from AiSvcTest.transaction_helper import createDocumentAndRetrieveId, getTransactionManagerPort, clean_work_folder

# Constants
DATE_CREATED = datetime.now()
transaction_results_folder = "result"
transaction_manager = None
logger = AiSvcTestLogger('AiSvcTest.transaction_manager')
logger_file_only = AiSvcTestLogger('AiSvcTest.transaction_manager.fileonly')


class TransactionStatus(Enum):
    """
    Enum for Transaction status.
    """
    ANALYSIS_PENDING = "ANALYSIS_PENDING"
    ANALYSIS_COMPLETE = "ANALYSIS_COMPLETE"
    ANALYSIS_REVIEWED = "ANALYSIS_REVIEWED"
    ANALYSIS_FAILED = "ANALYSIS_FAILED"

    def describe(self):
        return self.name, self.value

    def __str__(self):
        """str: Returns the string value for the enumeration."""
        return 'Status is {0}'.format(self.value)

    @classmethod
    def default(cls):
        """Returns a new status with ANALYSIS_COMPLETE enumeration as value."""
        # cls here is the enumeration
        return cls.ANALYSIS_COMPLETE


class Transaction(Resource):
    """
    A class for creating and handling Transaction.

    Attributes:
        transaction_id (int): Unique transaction identifier.
        studyUID (str): The unique DICOM Study id of the exam being analyzed.
        accessionNumber (str): The accession number of the study.
        status (str): The status of the transaction within the analysis process.
        dateCreated (datetime): The date when transaction was created.
        lastUpdated (datetime): The date when transaction was updated.
    """
    transaction_id = -1
    studyUID = STUDY_UID_PREFIX
    accessionNumber = ACCESION_NUMBER_PREFIX
    status = TransactionStatus.ANALYSIS_PENDING
    dateCreated = DATE_CREATED
    lastUpdated = DATE_CREATED

    def __init__(self):
        """ Default Constructor. """
        pass


class TransactionManagerConfig(metaclass=MetaFlaskEnv):
    """ A Python-Flask REST Endpoint configuration class for creating and handling Transaction. """
    DEBUG = False
    TESTING = False
    ENV = FLASK_ENV


class TransactionManager:
    def __init__(self, output):
        global transaction_results_folder
        transaction_results_folder = output

        log_file = Path(transaction_results_folder, "aisvctest.log")
        # logger.add_file(log_file)
        logger_file_only.add_file(log_file, True)
        logger.info("TransactionManager is writing to " + str(log_file))

        logger.info('Transaction Results folder: {}'.format(transaction_results_folder))

        os.environ['WERKZEUG_RUN_MAIN'] = '1'

        self.manager = Thread(target=_start_transaction_manager, kwargs={"host": "0.0.0.0", "port": getTransactionManagerPort()})

    @property
    def daemon(self):
        return self.manager.daemon

    @daemon.setter
    def daemon(self, daemon):
        self.manager.daemon = daemon

    @staticmethod
    def reset_status():
        _transaction_manager_pipe.send(RESET_STATUS)

    def start(self):
        self.manager.start()
        # TODO does logging need to be updated for multiprocessing?

    @staticmethod
    def status():
        _transaction_manager_pipe.send(REQUEST_STATUS)
        return _transaction_manager_pipe.recv()


class TransactionManagerStatus:
    """
    A class for creating and handling overall Transaction Status.

    Attributes:
        complete (bool): Is this complete.
        dicom (int): Number of DICOM files that have been received.
        fhir (int): The accession number of the study.
        result (int): Number of results submitted.
        status (TransactionStatus): Actual status of this transaction.
    """
    __slots__ = 'complete', 'dicom', 'fhir', 'result', 'status'

    def __init__(self):
        self.complete = False  # Is this Analysis complete?
        self.dicom = 0  # Number of DICOM files that have been served
        self.fhir = 0  # Number of FHIR files that have been received
        self.result = 0  # Ask Gerry
        self.status = TransactionStatus.ANALYSIS_PENDING  # Current status of Transaction

    def validate(self):
        """
        ERROR: You must create a result exactly once for each job. You may upload one FHIR and multiple DICOM files within a single result.
        ERROR: Transaction status should be set exactly once. In the event of an error, set it to ANALYSIS_FAILED.
        ERROR: Exactly one FHIR document should be uploaded in your result.  You many include multiple observations inside a single DiagnosticReport object.
        ERROR: After the transaction status is set, no further calls to AI Marketplace should be made.
        """
        err_flag = False
        if self.fhir != 1:
            logger.error(ERROR_VAL_FHIR % self.fhir)
            err_flag = True
        if self.result != 1:
            logger.error(ERROR_VAL_RESULT % self.result)
            err_flag = True
        if self.status == TransactionStatus.ANALYSIS_PENDING:
            logger.error(ERROR_VAL_STATUS % self.status)
            err_flag = True
        if err_flag:
            logger.info(LOG_SPACER)

    def completed(self):
        self.complete = True

    def add_dicom(self):
        self.dicom += 1

    def add_fhir(self):
        self.fhir += 1

    def add_result(self):
        self.result += 1

    def reset(self):
        self.complete = False  # Is this Analysis complete?
        self.dicom = 0  # Number of DICOM files that have been served
        self.fhir = 0  # Number of FHIR files that have been received
        self.result = 0  # Number of result objects created
        self.status = TransactionStatus.ANALYSIS_PENDING  # Current status of Transaction


########################
#  Transaction Manager Status
########################
transaction_manager_status = TransactionManagerStatus()
_transaction_manager_pipe, __transaction_manager_pipe = Pipe()
# Messages
REQUEST_STATUS = "Get Current Status"
RESET_STATUS = "Reset Status"

########################
#  App configurations
########################
# Rest API initialization using Flask-RESTful
transaction_manager_app = Flask(__name__)
transaction_manager_app.config.from_object(TransactionManagerConfig)
transaction_manager_api = Api(transaction_manager_app)

# Setting up the API Endpoint URL
transaction_manager_api.add_resource(Transaction, "/transaction/1/transactions/<int:transaction_id>/results")

# Initialize logging for the Transaction Manager
log_names = ['werkzeug']
app_logs = map(lambda name: logging.getLogger(name), log_names)
for app_log in app_logs:
    for handler in app_log.handlers[:]:  # remove all old handlers
        app_log.removeHandler(handler)

log = logging.getLogger('werkzeug')
#  Set automatic logging level for flask
log.setLevel(logging.FATAL)


def shutdown_server():
    """ Shuts down the Python-Flask REST Endpoint server. """
    func = request.environ.get('werkzeug.server.shutdown')
    if func is None:
        raise RuntimeError(ERROR_NOT_RUNING_DEFAULT_FLASK_SERVER)
    func()


###########################################
# Service requests a file upload
############################################
@transaction_manager_app.route('/study/<transaction_id>/<transaction_study>')
def study(transaction_id, transaction_study):
    studies_folder = os.path.join(STUDIES_FOLDER, str(transaction_id))
    logger_file_only.info(INZ + "GET " + request.base_url)
    return send_from_directory(studies_folder, transaction_study, mimetype='application/octet-stream')


###########################################
# Stops the Transaction Manager Simulator
############################################
@transaction_manager_app.route(TRANSACTION_SHUTDOWN_ENDPOINT, methods=['POST'])
def shutdown():
    """
    Shutdowns the transaction manager simulator.
    """
    logger.debug("Shutdown server request made to " + TRANSACTION_SHUTDOWN_ENDPOINT)
    logger.info(LOG_SPACER)
    logger.info(OUTZ + "POST "+request.base_url)
    logger.info(HSPACE + "AiSvcTest listener Shutdown")
    shutdown_server()
    return TRANSACTION_SHUTDOWN_MSG, 200


################################
# Simulate Transaction Creation
################################
@transaction_manager_app.route('/transaction/1/transactions', methods=['POST'])
def _post_transactions():
    # Authorization Interceptor.
    if not authorizeRequest(request):
        return ERROR_CODE_401_UNAUTHORIZED_ACCESS, 401

    logger.debug(TRANSACTION_POST_REQUEST)

    transaction_id = createTransactionAndRetrieveId(transaction_manager_app.root_path)

    if transaction_id == -1:
        return ERROR_CODE_500_CREATE_TRANSACTION, 500

    # counter_clear()

    response_data = {
        'id': transaction_id,
        'service': {'id': SERVICE_ID},
        'priority': PRIORITY_ID,
        'dateCreated': '{:%Y-%m-%dT%H:%M:%SZ}'.format(DATE_CREATED),
        'lastUpdated': '{:%Y-%m-%dT%H:%M:%SZ}'.format(DATE_CREATED),
        'status': TransactionStatus.ANALYSIS_PENDING.value,
        'studyUID': '{0}-{1}'.format(STUDY_UID_PREFIX, transaction_id),
        'accessionNumber': '{0}{1}'.format(ACCESION_NUMBER_PREFIX, transaction_id)
    }

    logger.debug(TRANSACTION_STATUS % (str(transaction_id), TransactionStatus.ANALYSIS_PENDING.value))
    logger.debug(TRANSACTION_POST_RESPONSE)
    logger.debug(json.dumps(response_data))

    cachePostTransactionResponse(response_data, transaction_manager_app.root_path, transaction_id)

    return transaction_manager_app.response_class(
        response=json.dumps(response_data, sort_keys=False, indent=4),
        status=200,
        mimetype='application/json'
    )


########################################
# Simulate Transaction Status Update
########################################
@transaction_manager_app.route('/transaction/1/transactions/<int:transaction_id>', methods=['PUT'])
def update_transaction_status(transaction_id):
    # Authorization Interceptor.
    if not authorizeRequest(request):
        return ERROR_CODE_401_UNAUTHORIZED_ACCESS, 401
    elif not verifyContentType(request, CONTENT_TYPE_JSON):
        return ERROR_CODE_415_UNSUPPORTED_MEDIA_TYPE, 415

    json_data = request.get_json(force=True)
    if not request.is_json or not json_data or 'status' not in request.get_json():
        return ERROR_CODE_400_BAD_REQUEST, 400

    transaction_manager_status.completed()

    logger.debug(TRANSACTION_PUT_STATUS_REQUEST)
    logger.debug(json_data)
    transaction_manager_status.status = TransactionStatus(json_data['status'])

    logger_file_only.info(LOG_SPACER)
    logger_file_only.info(INZ + "PUT " + request.base_url)
    logger_file_only.info(HSPACE + "Setting transaction status to " + transaction_manager_status.status.value)
    logger_file_only.info(LOG_SPACER)
    transaction_manager_status.validate()

    # TODO: must override redirection to stderr for status updates

    response_data = {
        'id': transaction_id,
        'service': {'id': SERVICE_ID},
        'priority': PRIORITY_ID,
        'dateCreated': '{:%Y-%m-%dT%H:%M:%SZ}'.format(DATE_CREATED),
        'lastUpdated': '{:%Y-%m-%dT%H:%M:%SZ}'.format(DATE_CREATED),
        'status': transaction_manager_status.status.value,
        'studyUID': '{0}-{1}'.format(STUDY_UID_PREFIX, transaction_id),
        'accessionNumber': '{0}{1}'.format(ACCESION_NUMBER_PREFIX, transaction_id)
    }

    cachePostTransactionResponse(response_data, transaction_manager_app.root_path, transaction_id)

    # Cleans the work directory studies folder
    # Short-term fix, better fix is not to create temp folder at all
    clean_work_folder(transaction_id)

    return transaction_manager_app.response_class(
        response=json.dumps(response_data, sort_keys=False, indent=4),
        status=200,
        mimetype='application/json'
    )


########################################
# Simulate Transaction Result Creation
########################################
@transaction_manager_app.route('/transaction/1/transactions/<int:transaction_id>/results', methods=['POST'])
def post_results(transaction_id):
    # Authorization Interceptor.
    if not authorizeRequest(request):
        return ERROR_CODE_401_UNAUTHORIZED_ACCESS, 401
    elif not verifyContentType(request, CONTENT_TYPE_JSON):
        return ERROR_CODE_415_UNSUPPORTED_MEDIA_TYPE, 415

    json_data = request.get_json(force=True)
    if not request.is_json or not json_data:
        return ERROR_CODE_400_BAD_REQUEST, 400

    logger.debug(TRANSACTION_POST_RESULT_REQUEST)
    logger.debug(json_data)

    result_id = createResultAndRetrieveId(transaction_manager_app.root_path, transaction_id)
    transaction_manager_status.add_result()

    # url_path = urlparse(request.base_url).path
    logger_file_only.info(LOG_SPACER)
    logger_file_only.info(INZ + "POST " + request.base_url)
    logger_file_only.info(HSPACE + "Created new result object: " + str(transaction_manager_status.result))

    if result_id == -1:
        return ERROR_CODE_500_CREATE_RESULT, 500

    response_data = {
        'id': result_id,
        'transaction': {'id': transaction_id},
        'dateCreated': '{:%Y-%m-%dT%H:%M:%SZ}'.format(DATE_CREATED),
        'lastUpdated': '{:%Y-%m-%dT%H:%M:%SZ}'.format(DATE_CREATED),
        'resultType': RESULT_TYPE
    }

    if 'serviceKey' in request.get_json():
        service_key = json_data['serviceKey']
        if isNotBlank(service_key):
            # Available to the AI Model for tracking purposes to identify the instance of the AI Model
            response_data['serviceKey'] = service_key
    if 'resultKey' in request.get_json():
        result_key = str(json_data['resultKey'])
        if isNotBlank(result_key):
            # Available to the AI Model for tracking purposes to associate with the results as produced by the AI Model
            response_data['resultKey'] = result_key

    logger.debug(TRANSACTION_POST_RESULT_RESPONSE)
    logger.debug(json.dumps(response_data))

    cachePostResultResponse(response_data, transaction_manager_app.root_path, transaction_id)

    return transaction_manager_app.response_class(
        response=json.dumps(response_data, sort_keys=False, indent=4),
        status=201,
        mimetype='application/json'
    )


##########################################################
# Simulate Document Uploads for FHIR json or StudyResults
###########################################################
@transaction_manager_app.route('/transaction/1/transactions/<int:transaction_id>/results/<int:result_id>/documents', methods=['POST'])
def post_documents(transaction_id, result_id):
    # Authorization Interceptor.
    if not authorizeRequest(request):
        return ERROR_CODE_401_UNAUTHORIZED_ACCESS, 401
    elif not verifyContentType(request, CONTENT_TYPE_FORM):
        return ERROR_CODE_415_UNSUPPORTED_MEDIA_TYPE, 415

    if 'file' not in request.files:
        logger.error('No file uploaded')
        return ERROR_CODE_400_BAD_REQUEST, 400

    url_path = urlparse(request.base_url).path
    # future requirement
    req_doc_type = request.headers.get("DocumentType")

    # Image info
    img_file = request.files.get('file')
    img_name = img_file.filename
    img_extn = os.path.splitext(img_name)[1].lower()
    mimetype = img_file.content_type
    document_id = -1

    # if (not mimetype):
    #     mimetype = os.path.splitext(img_name)[1][1:]

    logger_file_only.info(LOG_SPACER)
    logger_file_only.info(INZ + "POST " + request.base_url + " for '" + img_name + "'")
    # logger_file_only.info(LOG_SPACER)
    # logger_file_only.info("DOC request header:" + str(request.headers))
    # logger_file_only.info("FILE header: " + str(img_file))
    # logger_file_only.info("FORM header: " + str(request.form))
    # logger_file_only.info(LOG_SPACER)

    if img_file.filename == '':
        logger.error('No filename in uploaded file')
        return ERROR_CODE_400_BAD_REQUEST, 400
    elif img_extn != '.json' and \
            img_extn != '.dcm' and \
            img_extn != '.log':
        logger.error('Upload from AI Service failed: file type must be .log, .json or .dcm')
        return ERROR_CODE_400_BAD_REQUEST, 400
    else:
        verifyMimeType(img_name, mimetype)
        if not persistDocumentUploads(img_file, transaction_results_folder, transaction_id):
            return ERROR_CODE_500_MULTIPART_FILE_UPLOAD, 500
        document_id = createDocumentAndRetrieveId(img_file, transaction_manager_app.root_path, transaction_id, result_id)

        spacer = False
        if img_extn == '.json':
            transaction_manager_status.add_fhir()
            results_directory = os.path.join(transaction_results_folder, str(transaction_id))
            destination = os.path.abspath(os.path.join(results_directory, img_file.filename))

            drv = DiagnosticReportValidator()
            if drv.load_file(destination):
                drv.validate()
                result = drv.get_errors()
                if len(result) > 0:
                    for r in result:
                        logger.error(drv.get_error_message(r))
                    logger.info(LOG_SPACER)

        elif img_extn == '.dcm':
            transaction_manager_status.add_dicom()

    if document_id == -1:
        return ERROR_CODE_500_MULTIPART_FILE_UPLOAD, 500

    response_data = {
        'id': document_id,
        'result': {'id': result_id},
        'dateCreated': '{:%Y-%m-%dT%H:%M:%SZ}'.format(DATE_CREATED),
        'lastUpdated': '{:%Y-%m-%dT%H:%M:%SZ}'.format(DATE_CREATED),
        'name': img_name,
        'documentType': mimetype
    }

    logger.debug(TRANSACTION_POST_DOCUMENT_RESPONSE)
    logger.debug(json.dumps(response_data))

    cachePostDocumentResponse(response_data, transaction_manager_app.root_path, transaction_id, result_id)

    return transaction_manager_app.response_class(
        response=json.dumps(response_data, sort_keys=False, indent=4),
        status=201,
        mimetype='application/json'
    )


def __listen():
    while True:
        _message = __transaction_manager_pipe.recv()
        if _message == REQUEST_STATUS:
            __transaction_manager_pipe.send(transaction_manager_status)
        elif _message == RESET_STATUS:
            transaction_manager_status.reset()


def _start_transaction_manager(host, port):
    Thread(target=__listen, daemon=True).start()
    transaction_manager_app.run(host, port)


def start_transaction_manager(output) -> TransactionManager:
    global transaction_manager
    transaction_manager = TransactionManager(output)
    transaction_manager.start()
    return transaction_manager
