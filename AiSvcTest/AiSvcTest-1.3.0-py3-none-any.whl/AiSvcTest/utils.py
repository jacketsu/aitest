"""

Copyright (c) 2019 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import os
import socket
import shutil
import sys
import json
import collections
import configparser
import docker
import logging

import pyfiglet

from AiSvcTest.logs import AiSvcTestLogger
from AiSvcTest.transaction_helper import shutdownTransactionManager, setTransactionManagerPort
from AiSvcTest.constants import *

logger = AiSvcTestLogger('AiSvcTest.transaction_manager')

AIT_VERSION = "1.3.0"
orig_stdout = None
f = None
keep_alive = None
host_address = None
external_host_address = None
# AiTest Configurations
# MAX_RETRIES = int(eval(configFileParser.get('AiTest', 'maxRetries')))
MAX_RETRIES = int(os.getenv('AST_MAXRETRIES', '3'))


def getRetryConfiguration():
    """
    Returns the value of number of retries.
    """
    return MAX_RETRIES


def gracefullyExit():
    """
    Gracefully Exit this application.
    """
    global orig_stdout
    global f

    if orig_stdout:
        sys.stdout = orig_stdout
        f.close()

    shutdownTransactionManager(1)  # Try one time to shutdown

    logging.shutdown()  # prevent deadlock

    # sys.exit()  # why call again here?


def stopServer():
    """
    Shutdown Transaction Manager without any retries.
    """
    shutdownTransactionManager(0)
    sys.exit()


def isNotBlank(anyString):
    """
    Checks if a given String is not empty (""), not null and not whitespace only.

    isNotBlank("")    # False
    isNotBlank("   ") # False
    isNotBlank("ok")  # True
    isNotBlank(None)  # False
    """
    return bool(anyString and anyString.strip())


def isBlank(anyString):
    """
    Checks if a given String is empty (""), null and whitespace only.

    isBlank("")    # True
    isBlank("   ") # True
    isBlank("ok")  # False
    isBlank(None)  # True
    """
    return not isNotBlank(anyString)

def get_external_address():
    return external_host_address

def set_external_adderss(new_address):
    if new_address:
        global external_host_address
        external_host_address = new_address
        logger.info(HSPACE)
        logger.info("Setting external Host address to: "+new_address)
        logger.info(HSPACE)

        unused_hostname, port = new_address.split(':')
        if port:
            logger.info("Setting Host port to: "+port)
            setTransactionManagerPort(port)
            logger.info(HSPACE)

def set_host_address(new_address):
    global host_address
    host_address = new_address

def getIpAddress():
    """
    Retrieves the IP Address of the system running this tool,
    so that it can be used by Transaction Manager simulator
    and also for sharing the DICOM Images to Algorithm.

    Returns:
        IP Address of the system.
    """
    global host_address

    if host_address is not None:
        ipAddress = host_address
    else:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ipAddress = '127.0.0.1'  # Default to Local host.
        try:
            # doesn't even have to be reachable
            s.connect(('10.255.255.255', 1))
            ipAddress = s.getsockname()[0]
        except Exception:
            logger.error(ERROR_RETRIEVING_IP)

        # logDebug(SYSTEM_IP_ADDRESS % str(ipAddress))
    return ipAddress


def createFolder(folder, shouldRecreate=False):
    """
    This function will create the given folder if it not exists.

    Args:
        folder (str): The directory to create.
        shouldRecreate (bool): Flag to recreate the given folder by deleting if it exists.
    """
    if not os.path.exists(folder):
        try:
            logger.debug(MSG_CREATING_FOLDER % os.path.abspath(folder))
            os.makedirs(os.path.abspath(folder))
        except OSError as e:
            logger.error(ERROR_COULDNOT_CREATE_FOLDER % os.path.abspath(folder))
            logger.error(e)
    elif shouldRecreate:
        try:
            logger.debug(MSG_REMOVING_FOLDER % folder)
            shutil.rmtree(folder)
            logger.debug(MSG_CREATING_FOLDER % folder)
            os.makedirs(folder)
        except OSError as e:
            logger.error(ERROR_RECREATE_FOLDER % folder)
            logger.error(e)


def getNextIncrementedId(output_folder):
    """
    Function to generate an unique Id in an incremental way by scanning through
    the output folder where previous ids are stored as folder names.

    Args:
        output_folder (str): Path where previous ids are stored as folder names.

    Returns:
        Next avaiable id, incremented value.
    """
    directories = list(filter(lambda d: os.path.isdir(os.path.join(output_folder, d)), os.listdir(output_folder)))
    directories = sorted(directories, key=lambda f: int(os.path.splitext(f)[0]))
    logger.debug(NEXT_INCREMENTED_ID % os.path.abspath(output_folder))
    if len(directories) == 0:
        logger.debug(NEXT_ID % '1')
        return 1
    else:
        nextID = int(directories[-1]) + 1
        if nextID < 1:
            logger.debug(NEXT_ID_LESS_THAN_ONE % nextID)
            logger.debug(NEXT_ID % '1')
            return 1
        logger.debug(NEXT_ID % str(nextID))
        return nextID


def getFiles(input_folder):
    """ Returns an array of top level files from a given input folder """
    files = []
    for folder, subs, filenames in os.walk(input_folder):
        files.extend(filenames)
        break  # Break here to retrieve only top level directory files.
    return files


def writeFile(file, data):
    """
    This function writes the given data to output file

    Args:
        file (str): The path of the output file
        data (str): The data to be written
    """
    # NOTE: Could add file existence checking and file overwriting
    # protection
    try:
        out_file = open(file, mode="w", encoding="utf-8")
        out_file.write(data)
    except IOError:
        logger.error(ERROR_COULDNOT_WRITE_FILE % (file))


def writeJsonFile(filename, data):
    """
    This function writes the given data to output file

    Args:
        filename (str): The path of the output file
        data (str): The JSON data to be written
    """
    try:
        json_data = []
        if not os.path.isfile(filename):
            json_data.append(data)
            with open(filename, mode='w') as f:
                f.write(json.dumps(json_data, sort_keys=False, indent=4))
        else:
            with open(filename) as feedsjson:
                feeds = json.load(feedsjson)
            feeds.append(data)
            with open(filename, mode='w') as f:
                f.write(json.dumps(feeds, sort_keys=False, indent=4))
    except IOError:
        logger.error(ERROR_COULDNOT_WRITE_FILE % (filename))

def getValid(alldata):
    """
    This function extracts only valid configuration from a json structure

    Args:
        alldata (json): The complete contents extracted from a configuration file
    """

    config = {}
    if len(alldata) > 0 and isinstance(alldata, collections.Mapping):
        for cfg in CONFIG_ALL:
            res = alldata.get(cfg)
            if res:
                config[cfg] = res
    return config

def readJsonFile(filename):
    """
    This function reads a file and extracts json from it

    Args:
        filename (str): The path of the JSON file
        data (str): The JSON data extracted from the file
    """
    try:
        if os.path.isfile(filename):
            with open(filename) as jsonfile:
                data = json.load(jsonfile)
                return data
    except IOError:
        logger.error(ERROR_COULDNOT_READ_FILE % (filename))
    except ValueError:
        logger.error(ERROR_COULDNOT_PARSE_JSON % (filename))
    return {}

def showBanner():
    """ Displays the banner for CLI command """
    test_banner = pyfiglet.figlet_format("AiSvcTest  " + AIT_VERSION, width=80)
    sys.stdout.write(test_banner)

def showTransactionManagerBanner():
    """ Displays the banner for Transaction Manager simulator """
    test_banner = pyfiglet.figlet_format("Transaction  Manager", width=132)
    sys.stdout.write(test_banner)

def check_max_mem():
    """Check the max memeory usage for aiservice docker container and output to console"""
    try:
        client = docker.from_env()
        containers = client.containers.list()
        for c in containers:
            if c.name == "aiservice":
                max_usage = c.stats(stream=False)["memory_stats"]["max_usage"] / 1024 / 1024 / 1024
                logger.info("Memory consumed: " + str(max_usage) + " GiB")
                return
        logger.error("aiservice container not running")
    except Exception as e:
        logger.error("Docker Memory Usage not Available: " + str(e))

def counter_clear():
    '''
      clear all of the tranaction counters
    '''
    for key in val_counters.keys():
        val_counters[key] = 0

def counter_inc(key):
    temp = val_counters.get(key, None)
    if temp is None:
        logger.error("Cannot increment unknown validateion value: "+key)
    val_counters[key] = temp+1

def counter_get(key):
    temp = val_counters.get(key, None)
    if temp is None:
        logger.error("Cannot read unknown validateion value: "+key)
    return temp

def validate_transaction():
    '''
        ERROR: You must create a result exactly once for each job. You may upload one FHIR and multiple DICOM files within a single result.
        ERROR: Transaction status should be set exactly once. In the event of an error, set it to ANALYSIS_FAILED.
        ERROR: Exactly one FHIR document should be uploaded in your result.  You many include multiple observations inside a single DiagnosticReport object.
        ERROR: After the transaction status is set, no further calls to AI Marketplace should be made.
        val_counters = {
            "fhir": 0,
            "dicom": 0,
            "result": 0,
            "status": 0,
            "complete": 9
        }
    '''
    cnt_fhir = counter_get("fhir")
    err_flag = False
    if cnt_fhir != 1:
        logger.error(ERROR_VAL_FHIR % (cnt_fhir))
        err_flag = True
    cnt_result = counter_get("result")
    if cnt_result != 1:
        logger.error(ERROR_VAL_RESULT % (cnt_result))
        err_flag = True
    cnt_status = counter_get("status")
    if cnt_status != 1:
        logger.error(ERROR_VAL_STATUS % (cnt_status))
        err_flag = True
    if err_flag:
        logger.info(LOG_SPACER)
