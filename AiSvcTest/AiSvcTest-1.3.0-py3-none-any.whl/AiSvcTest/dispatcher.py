"""

Copyright (c) 2019 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import requests
import time

from threading import Timer

from AiSvcTest.algorithm import Algorithm
from AiSvcTest.constants import *
from AiSvcTest.logs import AiSvcTestLogger
from AiSvcTest.transaction_helper import storeDicomImages
from AiSvcTest.utils import readJsonFile, getValid, check_max_mem
from AiSvcTest.transaction_manager import TransactionStatus

logger = AiSvcTestLogger('AiSvcTest.transaction_manager')

class Dispatcher:
    """
    API class for orchestrating the Ai Service Testing.
    """

    def __init__(self, ai_service_base_url, is_self_host: bool = False, transaction_manager=None):
        """ Constructor. """
        self.active = True
        self.algo = Algorithm(ai_service_base_url, is_self_host)
        self.base_url = ai_service_base_url
        self.self_host = is_self_host
        self.transaction_manager = transaction_manager

    def __call__(self, input_path, results_path, ai_service_path, transaction_id, config_file, transaction_manager=None):
        """
        Calling the dispatcher to execute the algorithm.

        Arguments:
            input_path (str): Input folder containing the input dicom images (study)
            results_path (str): Output folder to store the results from AI algorithm
            ai_service_path (str): AI Service Algorithm Endpoint url
            transaction_id (int): Transaction Identifier
        """
        logger.debug(ALGO_EXECUTION_STARTED)
        logger.debug("input = " + input_path)
        logger.debug("output = " + results_path)
        logger.debug("ai svc url = " + self.base_url + ai_service_path)
        logger.debug("transactionId = " + str(transaction_id))

        if transaction_manager is not None:
            self.transaction_manager = transaction_manager
        if config_file is not None:
            logger.debug("config = " + config_file)

        # Store the input dicom files and make it available to aiSvc.
        studies = storeDicomImages(input_path, transaction_id)
        logger.debug("studies = " + ', '.join(studies))

        config_data = None
        if config_file is not None:
            config_data = getValid(readJsonFile(config_file))
            if len(config_data) < 1:
                config_data = None

        try:
            algo_execution = self.algo.with_results(transaction_id, studies, results_path, config_data).execute(ai_service_path, ALGO_EXECUTE_HTTP_METHOD).ok

            if self.self_host:
                # algo returned before test is complete
                algo_execution = self.check_transaction_manager_read_status()
            else:
                check_max_mem()

            if algo_execution is True:
                logger.debug(ALGO_EXECUTION_SUCCESS)
            else:
                logger.error(ALGO_EXECUTION_FAILED)

        except Exception as e:
            logger.error(ERROR_EXECUTING_ALGO)
            logger.error(e)

    def check_live(self, quiet: bool = False) -> bool:
        if self.active:
            timer = Timer(TIMER_REFRESH, self.check_live, args=[True])
            timer.daemon = True
            timer.start()
        try:
            return self.algo.check_live(quiet, self.self_host).ok
        except requests.RequestException as e:
            logger.error("AI Service {URL} has not responded to a liveness check".format(URL=self.base_url))
            logger.debug(e)
            return False

    def kill_service(self):
        self.active = False
        return self.algo.shutdown_service().ok

    def check_transaction_manager_read_status(self) -> bool:
        local_status = self.transaction_manager.status()
        while not local_status.complete:
            logger.info("Status is " + str(local_status))
            time.sleep(TIMER_REFRESH)
            local_status = self.transaction_manager.status()
        return local_status.status == TransactionStatus.ANALYSIS_COMPLETE
