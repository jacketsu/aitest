"""

Copyright (c) 2019 Nuance Communications, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

"""
import os
import argparse

from AiSvcTest.constants import *
from AiSvcTest.logs import AiSvcTestLogger
from AiSvcTest.utils import isBlank, getFiles

logger = AiSvcTestLogger('AiSvcTest.transaction_manager')


def parseArgs():
    """Parse the command line arguments for AiSvcTest."""

    # Create the argument parser
    parser = argparse.ArgumentParser(allow_abbrev=False,
                                     description=HELP_TOOL_DESCRIPTION)

    # Add CLI arguments
    parser.add_argument("-i",
                        "--input",
                        metavar="<input_folder>",
                        action="store",
                        type=str,
                        required=True,
                        help=HELP_INPUT)

    parser.add_argument("-o",
                        "--output",
                        metavar="<output_folder>",
                        action="store",
                        type=str,
                        required=True,
                        help=HELP_OUTPUT)

    parser.add_argument("-s",
                        "--aiservice",
                        metavar="<ai_service>",
                        action="store",
                        type=str,
                        required=True,
                        help=HELP_AISERVICE)

    parser.add_argument("-k",
                        "--keepalive",
                        action="store_true",
                        help=HELP_KEEPALIVE)

    parser.add_argument("-sh",
                        "--selfhost",
                        action="store_true",
                        help=HELP_SELFHOST)

    parser.add_argument("--host",
                        metavar="<host>",
                        action="store",
                        type=str,
                        required=False,
                        help=HELP_HOST)

    parser.add_argument('-v',
                        '--verbose',
                        const=10,
                        default=20,
                        dest='verbose',
                        action='store_const',
                        help='Be more verbose with output (DEBUG)')

    return parser.parse_args()

def validateInputs(args):
    """Validates the input arguments."""
    input_path = args.input
    output_path = args.output
    aisvc_url = args.aiservice
    logger.debug(VALIDATE_INPUT_ARGS)

    # Validate if input folder exists.
    if (not os.path.isdir(input_path)):
        logger.error(ERROR_INVALID_INPUT % input_path)
        return False
    logger.debug(ARGS_INPUT % input_path)

    # Validate if input folder and outfolder are not same.
    if (os.path.abspath(input_path).lower() == os.path.abspath(output_path).lower()):
        logger.error(ERROR_SAME_INPUT_AND_OUTPUT % (input_path, output_path))
        return False
    logger.debug(ARGS_OUTPUT % output_path)

    # Validate the service url
    if (isBlank(aisvc_url) or not (aisvc_url.startswith('http://') or aisvc_url.startswith('https://'))):
        logger.error(ERROR_INVALID_AI_SERVICE_URL)
        logger.debug(aisvc_url)
        return False
    logger.debug(ARGS_AISVC % aisvc_url)

    # Validate if input folder has dicom images in it.
    inputFiles = [f for f in os.listdir(input_path) if f.lower().endswith('.dcm')]
    if (len(inputFiles) == 0):
        logger.error(ERROR_NO_DICOM_IMAGES % os.path.abspath(input_path))
        return False

    # Debug Logging for troubleshooting purpose.
    files = getFiles(input_path)
    logger.debug(TOTAL_FILES_FOUND % (len(files), input_path))
    for file in files:
        logger.debug("\t\t%s" % file)

    return True
